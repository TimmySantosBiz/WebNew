function Pricing() {
    try {
        const plans = [
            {
                name: "Starter",
                price: "29",
                features: [
                    "Up to 5 team members",
                    "Basic analytics",
                    "24/7 support",
                    "API access",
                    "1 GB storage"
                ]
            },
            {
                name: "Professional",
                price: "99",
                popular: true,
                features: [
                    "Up to 20 team members",
                    "Advanced analytics",
                    "Priority support",
                    "API access",
                    "10 GB storage",
                    "Custom integrations"
                ]
            },
            {
                name: "Enterprise",
                price: "299",
                features: [
                    "Unlimited team members",
                    "Enterprise analytics",
                    "Dedicated support",
                    "API access",
                    "Unlimited storage",
                    "Custom integrations",
                    "SLA guarantee"
                ]
            }
        ];

        return (
            <section id="pricing" data-name="pricing" className="py-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 data-name="pricing-title" className="text-4xl font-bold mb-4 text-glow">
                            Simple, Transparent Pricing
                        </h2>
                        <p data-name="pricing-subtitle" className="text-xl text-gray-300">
                            Choose the plan that's right for you
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {plans.map((plan, index) => (
                            <div
                                key={index}
                                data-name={`pricing-card-${index}`}
                                className={`glass-card p-8 rounded-lg relative ${
                                    plan.popular ? 'border-2 border-[#7C4DFF]' : ''
                                }`}
                            >
                                {plan.popular && (
                                    <div className="absolute top-0 right-0 bg-[#7C4DFF] text-white px-4 py-1 rounded-bl-lg rounded-tr-lg">
                                        Popular
                                    </div>
                                )}
                                <h3 className="text-2xl font-bold mb-4">{plan.name}</h3>
                                <div className="mb-6">
                                    <span className="text-4xl font-bold">${plan.price}</span>
                                    <span className="text-gray-400">/month</span>
                                </div>
                                <ul className="space-y-4 mb-8">
                                    {plan.features.map((feature, featureIndex) => (
                                        <li key={featureIndex} className="flex items-center">
                                            <i className="fas fa-check text-[#7C4DFF] mr-2"></i>
                                            <span className="text-gray-300">{feature}</span>
                                        </li>
                                    ))}
                                </ul>
                                <button className={`w-full py-3 rounded-lg transition-colors ${
                                    plan.popular
                                        ? 'bg-gradient-to-r from-[#7C4DFF] to-[#9D7FFF] text-white'
                                        : 'border border-[#7C4DFF] text-white hover:bg-[#7C4DFF]'
                                }`}>
                                    Get Started
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Pricing error:', error);
        reportError(error);
        return null;
    }
}
