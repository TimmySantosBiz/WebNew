function Hero() {
    try {
        return (
            <div data-name="hero" className="pt-20 pb-16 text-center lg:pt-32 lg:pb-24">
                <div className="px-4 sm:px-8 max-w-7xl mx-auto">
                    <h1 data-name="hero-title" className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-8 text-glow">
                        Transform Your Business with 
                        <span className="gradient-text"> CloudFlow</span>
                    </h1>
                    <p data-name="hero-subtitle" className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto">
                        Streamline your operations, boost productivity, and scale your business with our innovative SaaS platform.
                    </p>
                    <div data-name="hero-cta" className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
                        <button className="px-8 py-4 bg-gradient-to-r from-[#7C4DFF] to-[#9D7FFF] rounded-lg text-white font-bold hover:opacity-90 transition-opacity">
                            Start Free Trial
                        </button>
                        <button className="px-8 py-4 border border-[#7C4DFF] rounded-lg text-white hover:bg-[#7C4DFF] transition-colors">
                            Watch Demo
                        </button>
                    </div>
                    <div data-name="hero-stats" className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
                        <div className="glass-card p-6 rounded-lg">
                            <div className="text-3xl font-bold gradient-text">99%</div>
                            <div className="text-gray-400">Uptime</div>
                        </div>
                        <div className="glass-card p-6 rounded-lg">
                            <div className="text-3xl font-bold gradient-text">10k+</div>
                            <div className="text-gray-400">Users</div>
                        </div>
                        <div className="glass-card p-6 rounded-lg">
                            <div className="text-3xl font-bold gradient-text">3.5M</div>
                            <div className="text-gray-400">API Calls</div>
                        </div>
                        <div className="glass-card p-6 rounded-lg">
                            <div className="text-3xl font-bold gradient-text">24/7</div>
                            <div className="text-gray-400">Support</div>
                        </div>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('Hero error:', error);
        reportError(error);
        return null;
    }
}
