function Navbar() {
    try {
        const [isOpen, setIsOpen] = React.useState(false);

        return (
            <nav data-name="navbar" className="fixed w-full z-50 bg-opacity-90 bg-[#121212] backdrop-blur-md">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16 items-center">
                        <div className="flex-shrink-0" data-name="logo">
                            <span className="text-2xl font-bold gradient-text">CloudFlow</span>
                        </div>
                        
                        <div className="hidden md:block" data-name="desktop-menu">
                            <div className="ml-10 flex items-baseline space-x-4">
                                <a href="#features" className="text-gray-300 hover:text-white px-3 py-2 rounded-md">Features</a>
                                <a href="#pricing" className="text-gray-300 hover:text-white px-3 py-2 rounded-md">Pricing</a>
                                <a href="#testimonials" className="text-gray-300 hover:text-white px-3 py-2 rounded-md">Testimonials</a>
                                <button className="bg-gradient-to-r from-[#7C4DFF] to-[#9D7FFF] text-white px-4 py-2 rounded-md">
                                    Get Started
                                </button>
                            </div>
                        </div>
                        
                        <div className="md:hidden" data-name="mobile-menu-button">
                            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-300 hover:text-white">
                                <i className={`fas ${isOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
                            </button>
                        </div>
                    </div>
                </div>

                {isOpen && (
                    <div className="md:hidden" data-name="mobile-menu">
                        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                            <a href="#features" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md">Features</a>
                            <a href="#pricing" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md">Pricing</a>
                            <a href="#testimonials" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md">Testimonials</a>
                            <button className="w-full text-center bg-gradient-to-r from-[#7C4DFF] to-[#9D7FFF] text-white px-4 py-2 rounded-md">
                                Get Started
                            </button>
                        </div>
                    </div>
                )}
            </nav>
        );
    } catch (error) {
        console.error('Navbar error:', error);
        reportError(error);
        return null;
    }
}
