function Features() {
    try {
        const features = [
            {
                icon: "fa-rocket",
                title: "Lightning Fast",
                description: "Experience blazing-fast performance with our optimized infrastructure."
            },
            {
                icon: "fa-shield",
                title: "Enterprise Security",
                description: "Bank-grade security measures to protect your sensitive data."
            },
            {
                icon: "fa-chart-line",
                title: "Real-time Analytics",
                description: "Get instant insights with our powerful analytics dashboard."
            },
            {
                icon: "fa-code",
                title: "API Integration",
                description: "Seamlessly integrate with your existing tools and workflows."
            },
            {
                icon: "fa-users",
                title: "Team Collaboration",
                description: "Work together efficiently with built-in collaboration tools."
            },
            {
                icon: "fa-clock",
                title: "24/7 Support",
                description: "Round-the-clock support to help you whenever you need it."
            }
        ];

        return (
            <section id="features" data-name="features" className="py-20 bg-[#1E1E1E]">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 data-name="features-title" className="text-4xl font-bold mb-4 text-glow">
                            Powerful Features
                        </h2>
                        <p data-name="features-subtitle" className="text-xl text-gray-300">
                            Everything you need to scale your business
                        </p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {features.map((feature, index) => (
                            <div 
                                key={index}
                                data-name={`feature-card-${index}`}
                                className="glass-card p-6 rounded-lg hover:transform hover:scale-105 transition-transform duration-300"
                            >
                                <div className="text-[#7C4DFF] text-3xl mb-4">
                                    <i className={`fas ${feature.icon}`}></i>
                                </div>
                                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                                <p className="text-gray-400">{feature.description}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Features error:', error);
        reportError(error);
        return null;
    }
}
