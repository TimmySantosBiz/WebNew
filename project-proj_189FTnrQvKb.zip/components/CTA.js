function CTA() {
    try {
        return (
            <section data-name="cta" className="py-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="glass-card p-12 rounded-2xl text-center">
                        <h2 data-name="cta-title" className="text-4xl font-bold mb-6 text-glow">
                            Ready to Transform Your Business?
                        </h2>
                        <p data-name="cta-subtitle" className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                            Join thousands of companies that trust CloudFlow to power their business operations.
                        </p>
                        <div className="flex flex-col sm:flex-row justify-center gap-4">
                            <button className="px-8 py-4 bg-gradient-to-r from-[#7C4DFF] to-[#9D7FFF] rounded-lg text-white font-bold hover:opacity-90 transition-opacity">
                                Start Free Trial
                            </button>
                            <button className="px-8 py-4 border border-[#7C4DFF] rounded-lg text-white hover:bg-[#7C4DFF] transition-colors">
                                Schedule Demo
                            </button>
                        </div>
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('CTA error:', error);
        reportError(error);
        return null;
    }
}
