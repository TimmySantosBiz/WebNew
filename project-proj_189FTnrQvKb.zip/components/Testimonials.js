function Testimonials() {
    try {
        const testimonials = [
            {
                name: "Sarah Johnson",
                role: "CEO at TechStart",
                image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80",
                quote: "CloudFlow has transformed how we operate. The efficiency gains are remarkable."
            },
            {
                name: "Michael Chen",
                role: "CTO at DataFlow",
                image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80",
                quote: "The best SaaS platform we've used. Incredible features and support team."
            },
            {
                name: "Emma Williams",
                role: "Product Manager at Scale",
                image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80",
                quote: "Outstanding platform that delivers on all its promises. Highly recommended!"
            }
        ];

        return (
            <section id="testimonials" data-name="testimonials" className="py-20 bg-[#1E1E1E]">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 data-name="testimonials-title" className="text-4xl font-bold mb-4 text-glow">
                            What Our Clients Say
                        </h2>
                        <p data-name="testimonials-subtitle" className="text-xl text-gray-300">
                            Trusted by leading companies worldwide
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {testimonials.map((testimonial, index) => (
                            <div
                                key={index}
                                data-name={`testimonial-card-${index}`}
                                className="glass-card p-6 rounded-lg"
                            >
                                <div className="mb-6">
                                    <i className="fas fa-quote-left text-4xl text-[#7C4DFF]"></i>
                                </div>
                                <p className="text-gray-300 mb-6 italic">
                                    "{testimonial.quote}"
                                </p>
                                <div className="flex items-center">
                                    <img
                                        src={testimonial.image}
                                        alt={testimonial.name}
                                        className="w-12 h-12 rounded-full mr-4"
                                    />
                                    <div>
                                        <div className="font-bold">{testimonial.name}</div>
                                        <div className="text-gray-400">{testimonial.role}</div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Testimonials error:', error);
        reportError(error);
        return null;
    }
}
