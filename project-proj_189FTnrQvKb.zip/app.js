function App() {
    try {
        return (
            <div data-name="app" className="min-h-screen bg-[#121212]">
                <Navbar />
                <Hero />
                <Features />
                <Pricing />
                <Testimonials />
                <CTA />
                <Footer />
            </div>
        );
    } catch (error) {
        console.error('App error:', error);
        reportError(error);
        return null;
    }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
